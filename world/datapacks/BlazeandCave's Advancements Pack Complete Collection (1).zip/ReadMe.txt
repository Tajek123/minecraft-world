Complete Collection v2.3.2
for BlazeandCave's Advancement Pack featuring a very hard to get advancement with appropriate xp gain, and a small secret advancement for doing it twice, or thrice, a reward that will confuse those not in on the joke, and a special trophy(?)
And it keeps growing with more advancements!


Turns out install function is unneeded, so...
this readme has little purpose
still keeping the universal install function just to troll though :barry:
(not anymore! i had to remove it in v2!)
just drag the file inside the unzip me to your world's "datapacks" folder

credits:
https://minecraft-heads.com for the Elder Guardian head

saladbowls for helping me with part of the trophy code

Jamsamamsa for the original Advancement idea

Cavinator1 for leaving this Advancement's fate unclear (oh and also making the original BACAP)

FixingGlobe for making the entire install function and making cereal dedication (from which I grabbed a bit of code from) also helping with a very small part of the advancement code but still helping also updating basically all of 1.5.0 and helping me fix bugs for 1.6.0 and helping me bugfix my horrible attempt at v2 

Wolfguy for a cornplete collection, which is this but different

Vee for suggesting the trophy for A Complete Collection!, I expanded a bit on it however

Ktano2o6o8 for helping a bit with the trophy code updating to 1.20.5 and other general bug reporting